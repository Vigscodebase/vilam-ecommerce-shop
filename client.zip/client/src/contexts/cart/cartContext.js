import React, { createContext, useReducer, useEffect } from 'react';
import { cartReducer, initializer } from './cartReducer';

// Cart-Context
const cartContext = createContext();

// Initial State
// const initialState = {
//     cartItems: []
// }

// Cart-Provider Component
const CartProvider = ({ children }) => {

    const [cart, dispatch] = useReducer(cartReducer, [], initializer);

    useEffect(() => {
        // console.log("Cart updated, persisting to local storage", cart);
        localStorage.setItem("cart", JSON.stringify(cart));
    }, [cart]);

    // Dispatched Actions
    const addItem = (item) => {
        return dispatch({
            type: 'ADD_TO_CART',
            item
        });
    };

    const removeItem = (item) => {
        return dispatch({
            type: 'REMOVE_FROM_CART',
            item
        });
    };

    const incrementItem = (item) => {
        return dispatch({
            type: 'INCREMENT_ITEM',
            item
        });
    };

    const decrementItem = (item) => {
        return dispatch({
            type: 'DECREMENT_ITEM',
            item
        });
    };

    const clearCart = () => ({
        type: "CLEAR_CART"
    });

    // Context values
    const values = {
        cart,
        addItem,
        removeItem,
        incrementItem,
        decrementItem,
        clearCart
    };

    return (
        <cartContext.Provider value={values}>
            {children}
        </cartContext.Provider>
    );
};


export default cartContext;
export { CartProvider };