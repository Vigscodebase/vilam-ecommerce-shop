const initialState = [];

export const initializer = (initialValue = initialState) =>
    JSON.parse(localStorage.getItem("cart")) || initialValue;

export const cartReducer = (state, action) => {

    switch (action.type) {

        case 'ADD_TO_CART':
            return state.find((item) => item.title === action.item.title)
                ? state.map((item) =>
                    item.title === action.item.title
                        ? {
                            ...item,
                            quantity: item.quantity + 1
                        }
                        : item
                )
                : [...state, { ...action.item, quantity: 1 }];

        case 'REMOVE_FROM_CART':
            return state.filter((item) => item.title !== action.item.title);

        // case 'INCREMENT_ITEM':
        //     return {
        //         ...state,
        //         cartItems: state.cartItems.map(item => {
        //             if (item.id === action.payload.itemId) {
        //                 return {
        //                     ...item,
        //                     quantity: item.quantity + 1
        //                 };
        //             }
        //             return item;
        //         })
        //     };

        case 'INCREMENT_ITEM':
            return state.find((item) => item.id === action.item.id)
                ? state.map((item) =>
                    item.id === action.item.id
                        ? {
                            ...item,
                            quantity: item.quantity + 1
                        }
                        : item
                )
                : [...state, { ...action.item, quantity: 1 }];

        case 'DECREMENT_ITEM':
            return state.find((item) => item.id === action.item.id)?.quantity ===
                1
                ? state.filter((item) => item.id !== action.item.id)
                : state.map((item) =>
                    item.id === action.item.id
                        ? {
                            ...item,
                            quantity: item.quantity - 1
                        }
                        : item
                );

        case "CLEAR_CART":
            return initialState;

        default:
            return state;
    }
};

// export default cartReducer;