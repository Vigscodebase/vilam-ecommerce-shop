import React from "react";
import PropTypes from "prop-types";

const AuthContext = React.createContext(null);

export const AuthProvider = ({ userData, userToken, children }) => {

    let [user, setUser] = React.useState(userData);
    let [token, setToken] = React.useState(userToken);

    user = user;
    token = token;

    return <AuthContext.Provider value={{ user, token, setUser, setToken }}>{children}</AuthContext.Provider>;
};

AuthProvider.propTypes = {
    userData: PropTypes.any,
    userToken: PropTypes.any,
    children: PropTypes.any,
};

export const useAuth = () => React.useContext(AuthContext);

// export default AuthContext;
// export { AuthProvider };