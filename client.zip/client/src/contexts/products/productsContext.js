import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import ProductApi from '../../api/product';

// ==== Products-Context ====
//
// THE BUG THIS REPLACES
// ----------------------
// `data/productsData.js` used to call `ProductApi.GetAllProducts()` and try
// to export the result as a plain array:
//
//     let temp_prod_data = [];
//     productApi.GetAllProducts().then(response => { temp_prod_data.push(...) });
//     const productsData = temp_prod_data;
//     export default productsData;
//
// Module code runs synchronously, but `.then()` doesn't. So by the time any
// component imported `productsData`, the array was always still empty - the
// network response hadn't arrived yet. Every place that did
// `useState(productsData)` or `useEffect(() => {...}, [])` with that array
// captured that permanently-empty snapshot and never re-rendered when the
// data actually showed up a moment later, because a plain array being
// mutated elsewhere doesn't trigger React re-renders.
//
// That's why the home page sliders/top products were always blank, "All
// Products" always showed "No Results Found", and the product-details page
// crashed outright (`productsData.find(...)` returned `undefined`, then the
// page tried to destructure fields off it).
//
// THE FIX
// -------
// Fetch the data inside a component using useEffect + useState, and hand it
// out through context so every consumer re-renders automatically once the
// request resolves.

const ProductsContext = createContext(null);

const normalizeProduct = (item) => ({
    id: item._id,
    tag: item.tag,
    tagline: item.tagline,
    heroImage: item.heroImage,
    images: Array.isArray(item.images) ? item.images : [],
    brand: item?.brand?.label ?? item?.brand ?? '',
    title: item.title,
    info: item.info,
    category: item?.category?.label ?? item?.category ?? '',
    type: item.type,
    connectivity: item.connectivity,
    finalPrice: item.finalPrice,
    originalPrice: item.originalPrice,
    quantity: item.quantity,
    ratings: item.ratings,
    rateCount: item.rateCount,
    path: item.path,
});

const ProductsProvider = ({ children }) => {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchProducts = useCallback(() => {
        setLoading(true);
        setError(null);

        return ProductApi.GetAllProducts()
            .then((response) => {
                const list = response?.data?.data ?? [];
                setProducts(list.map(normalizeProduct));
            })
            .catch((err) => {
                console.error('Failed to load products:', err);
                setError(err);
                setProducts([]);
            })
            .finally(() => {
                setLoading(false);
            });
    }, []);

    useEffect(() => {
        fetchProducts();
    }, [fetchProducts]);

    const values = {
        products,
        loading,
        error,
        refetchProducts: fetchProducts,
    };

    return (
        <ProductsContext.Provider value={values}>
            {children}
        </ProductsContext.Provider>
    );
};

// Hook form, matching the convention already used by contexts/auth/authContext.js
const useProducts = () => useContext(ProductsContext);

export default ProductsContext;
export { ProductsProvider, useProducts };
