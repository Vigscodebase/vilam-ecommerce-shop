
const OrderPlaced = () => {

    return (
        <h1>Order Placed</h1>
    )
}

export default OrderPlaced