import AuthApi from "../api/auth";
import { useEffect } from "react";
import Swal from 'sweetalert2'
import { useNavigate } from "react-router-dom";

const VerifyEmail = () => {

    const navigate = useNavigate();

    useEffect(() => {

        onVerify()

    }, []);

    const onVerify = () => {

        AuthApi.VerifyEmail()
            .then((response) => {
                if (response.data.success) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'success',
                        title: response.data.success
                    });
                    navigate("/");
                } else {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: response.data.message
                    });
                    navigate("/");
                }
            })
            .catch((error) => {
                if (error.response) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });
                    navigate("/");
                }

            });

    }

    return (
        <h1>Verify Email</h1>
    )

}

export default VerifyEmail