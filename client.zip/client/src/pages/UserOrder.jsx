import React from 'react';
import { useAuth } from "../contexts/auth/authContext"
import OrderApi from '../api/order';
import { Helmet } from "react-helmet";

const UserOrder = () => {

    const [orderobj, setOrderobj] = React.useState({})
    const { user } = useAuth();

    React.useEffect(() => {

        fetcSingleOrder()

    }, []);

    const fetcSingleOrder = () => {

        OrderApi.GetSingleOrderById(user)
            .then((response) => {

                let temp_order_data = []

                response.data.data.map(item => {

                    temp_order_data.push({
                        orderid: item.orderid,
                        orderproducts: item.orderproducts,
                        totalamount: item.totalamount,
                    })

                });

                setOrderobj(temp_order_data)
            })

    }

    return (

        <section id="cart" className="section">
            <Helmet>
                <title>Orders - Vilam Ecommerce</title>
            </Helmet>

            <div className="container">
                <div className="wrapper cart_wrapper">

                    <div className="cart_left_col">
                        <h1>Orders</h1>

                        {(Object.keys(orderobj).length != 0) ?

                            <div style={{ borderBottom: "1px solid rgba(102, 102, 102, 0.6)" }} className="cart_item">
                                <table style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse" }}>
                                    <tr>
                                        <th style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse" }}>Order Id</th>
                                        <th style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse" }}>Products</th>
                                        <th style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse" }}>Total Amount</th>
                                    </tr>

                                    {orderobj.map(item => {
                                        return (
                                            <tr key={item.orderid}>
                                                <td style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse" }}>{item.orderid}</td>
                                                <td style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse", paddingRight: "285px" }}>
                                                    {
                                                        item.orderproducts.map(prods => {
                                                            return (
                                                                <li>{prods}</li>
                                                            )
                                                        })
                                                    }
                                                </td>
                                                <td style={{ width: "100%", border: "1px solid pink", borderCollapse: "collapse" }}>{item.totalamount}</td>
                                            </tr>
                                        )
                                    })
                                    }
                                </table>
                            </div>
                            :

                            <div style={{ borderBottom: "1px solid rgba(102, 102, 102, 0.6)" }} className="cart_item">
                                <h1>You have not taken any orders.</h1>
                            </div>
                        }

                    </div>

                </div>
            </div>

        </section>

    )

}

export default UserOrder