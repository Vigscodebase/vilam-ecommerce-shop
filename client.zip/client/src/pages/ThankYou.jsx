import { useLocation } from 'react-router-dom';
import React from 'react';
import { Helmet } from "react-helmet";
import { Link } from 'react-router-dom';
import ProductImage from '../components/common/ProductImage';

const ThankYou = () => {

    const [cartcheckoutdata, setCartCheckoutData] = React.useState(null)
    const location = useLocation();
    React.useEffect(() => {

        if (location.state === null) {
            window.location.href = "/";
        }
        else {

            if (Object.keys(location.state)[0] === "cartcheckoutdata") {
                setCartCheckoutData(location.state.finalcartcheckoutdata)
            }
            else if (Object.keys(location.state)[0] === "buycheckoutdata") {

            }
            else {
                window.location.href = "/"
            }

        }


    }, []);

    // `cartcheckoutdata` starts out as `null` and is only populated once the
    // effect above runs (and only for the "cartcheckoutdata" case) - render
    // a lightweight loading state instead of destructuring/mapping over
    // data that isn't there yet, which used to throw immediately.
    if (!cartcheckoutdata || !cartcheckoutdata.cart) {
        return (
            <section id="cart" className="section">
                <Helmet>
                    <title>Thank You - Vilam Ecommerce</title>
                </Helmet>
                <div className="wrapper cart_wrapper">
                    <p style={{ padding: '40px' }}>Loading your order...</p>
                </div>
            </section>
        );
    }

    return (

        <section id="cart" className="section">
            <Helmet>
                <title>Thank You - Vilam Ecommerce</title>
            </Helmet>

            <div className="wrapper cart_wrapper">

                <div className="cart_left_col">
                    <h1>Your Order of {cartcheckoutdata.orderid} Order ID has been Successfully placed. Want to continue shopping please go to this link <a href="/all-products">here</a></h1>
                    <p style={{ marginTop: "20px" }}>{cartcheckoutdata.address}</p>
                </div>

                <div className="cart_right_col">
                    <div className="order_summary">
                        <div className="order_summary_details">
                            <div className="total_price">
                                <b><small>Total Price</small></b>
                                <b>{cartcheckoutdata.cart.totalprice}</b>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="cart_left_col">
                    <h1>Items</h1>
                    {
                        cartcheckoutdata.cart.cartitems.map(item => (

                            <div style={{ borderBottom: "1px solid rgba(102, 102, 102, 0.6)" }} className="cart_item" key={item.id}>
                                <figure className="cart_item_img">
                                    <Link to={`${item.path}${item.id}`}>
                                        {item.images &&
                                            <ProductImage src={item.images[0]} alt={item.title} />
                                        }
                                    </Link>
                                </figure>
                                <div className="cart_item_info">
                                    <div className="cart_item_head">
                                        <Link to={`${item.path}${item.id}`}>{item.title}</Link>
                                    </div>
                                    <h2 className="cart_item_price">
                                        ₹{item.finalPrice} &nbsp;
                                        <small><del>₹{item.originalPrice}</del></small>
                                    </h2>
                                </div>
                            </div>

                        ))
                    }
                </div>

            </div>

        </section>

    )

}

export default ThankYou