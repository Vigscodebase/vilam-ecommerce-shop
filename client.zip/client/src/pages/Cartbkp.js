import React, { useContext, useEffect } from 'react';
import { BsCartX } from 'react-icons/bs';
import { calculateTotal, displayMoney } from '../helpers/utils';
import useDocTitle from '../hooks/useDocTitle';
import cartContext from '../contexts/cart/cartContext';
// import CartItem from '../components/cart/CartItem';
import EmptyView from '../components/common/EmptyView';
import { TbTrash } from 'react-icons/tb';
import { Link } from 'react-router-dom';
import QuantityBox from '../components/common/QuantityBox';

const Cart = () => {

    useDocTitle('Cart');

    const { cart, removeItem } = useContext(cartContext);

    const cartQuantity = cart.length;

    // total original price
    // const cartTotal = cart.map(item => {
    //     return item.originalPrice * item.quantity;
    // });

    // const calculateCartTotal = calculateTotal(cartTotal);
    // const displayCartTotal = displayMoney(calculateCartTotal);


    // total discount
    // const cartDiscount = cart.map(item => {
    //     return (item.originalPrice - item.finalPrice) * item.quantity;
    // });

    // const calculateCartDiscount = calculateTotal(cartDiscount);
    // const displayCartDiscount = displayMoney(calculateCartDiscount);


    // final total amount
    // const totalAmount = calculateCartTotal - calculateCartDiscount;
    // const displayTotalAmount = displayMoney(totalAmount);


    return (
        <>
            <section id="cart" className="section">
                <div className="container">
                    {
                        cartQuantity === 0 ? (
                            <EmptyView
                                icon={<BsCartX />}
                                msg="Your Cart is Empty"
                                link="/all-products"
                                btnText="Start Shopping"
                            />
                        ) : (
                            <div className="wrapper cart_wrapper">
                                <div className="cart_left_col">
                                    {
                                        cart.map((item) => {

                                            const newPrice = displayMoney(item.finalPrice);
                                            const oldPrice = displayMoney(item.originalPrice);

                                            return (

                                                <div className="cart_item" key={item.id}>
                                                    <figure className="cart_item_img">
                                                        <Link to={`${item.path}${item.id}`}>
                                                            {item.images &&
                                                                <img src={item.images[0]} alt="product-img" />
                                                            }
                                                        </Link>
                                                    </figure>
                                                    <div className="cart_item_info">
                                                        <div className="cart_item_head">
                                                            <h4 className="cart_item_title">
                                                                <Link to={`/product-details/${item.id}`}>{item.title} {item.info}</Link>
                                                            </h4>
                                                            <div className="cart_item_del">
                                                                <span onClick={() => removeItem(item.id)}>
                                                                    <TbTrash />
                                                                </span>
                                                                <div className="tooltip">Remove Item</div>
                                                            </div>
                                                        </div>

                                                        <h2 className="cart_item_price">
                                                            {newPrice} &nbsp;
                                                            <small><del>{oldPrice}</del></small>
                                                        </h2>

                                                        <QuantityBox itemId={item.id} itemQuantity={item.quantity} />
                                                    </div>
                                                </div>

                                            );

                                        }

                                        )
                                    }
                                </div>

                                <div className="cart_right_col">
                                    <div className="order_summary">
                                        <h3>
                                            Order Summary &nbsp;
                                            ( {cartQuantity} {cartQuantity > 1 ? 'items' : 'item'} )
                                        </h3>
                                        <div className="order_summary_details">
                                            {
                                                cart.map((item) => {

                                                    const cartTotal = item.originalPrice * item.quantity
                                                    const calculateCartTotal = calculateTotal(cartTotal);
                                                    const displayCartTotal = displayMoney(calculateCartTotal);
                                                    const cartDiscount = (item.originalPrice - item.finalPrice) * item.quantity
                                                    const calculateCartDiscount = calculateTotal(cartDiscount);
                                                    const displayCartDiscount = displayMoney(calculateCartDiscount);
                                                    const totalAmount = item.calculateCartTotal - item.calculateCartDiscount;
                                                    const displayTotalAmount = displayMoney(totalAmount);

                                                    return (
                                                        <div key={item.id}>
                                                            <div className="price">
                                                                <span>Original Price</span>
                                                                <b>{displayCartTotal}</b>
                                                            </div>
                                                            <div className="discount">
                                                                <span>Discount</span>
                                                                <b>- {displayCartDiscount}</b>
                                                            </div>
                                                            <div className="delivery">
                                                                <span>Delivery</span>
                                                                <b>Free</b>
                                                            </div>
                                                            <div className="separator"></div>
                                                            <div className="total_price">
                                                                <b><small>Total Price</small></b>
                                                                <b>{displayTotalAmount}</b>
                                                            </div>
                                                        </div>
                                                    );
                                                }
                                                )
                                            }
                                        </div>
                                        <button type="button" className="btn checkout_btn">Checkout</button>
                                    </div>
                                </div>
                            </div>
                        )
                    }
                </div>
            </section>
        </>
    );
};

export default Cart;