import React, { useContext, useEffect, useState, useRef } from 'react';
import { BsCartX } from 'react-icons/bs';
import { calculateTotal, displayMoney } from '../helpers/utils';
import useDocTitle from '../hooks/useDocTitle';
import cartContext from '../contexts/cart/cartContext';
// import CartItem from '../components/cart/CartItem';
import EmptyView from '../components/common/EmptyView';
import { TbTrash } from 'react-icons/tb';
import { Link } from 'react-router-dom';
import QuantityBox from '../components/common/QuantityBox';
import { Helmet } from "react-helmet";
import { useAuth } from "../contexts/auth/authContext"
import SweetAlert from "react-bootstrap-sweetalert";
import Swal from 'sweetalert2'
import { useNavigate } from 'react-router-dom';
import { useForm } from "react-hook-form";
import AuthApi from "../api/auth"
import ProductImage from '../components/common/ProductImage';

const Cart = () => {

    // useDocTitle('Cart');

    const { cart, removeItem } = useContext(cartContext);
    const cartQuantity = cart.length;
    let { user, token, setUser, setToken } = useAuth();
    const [isForm, setisForm] = useState(false)
    const formRef = useRef()
    const [error, setError] = useState({
        email: " ",
        password: " ",
        fatalError: " "
    });
    const [formData, setFormData] = useState({});
    const navigate = useNavigate();

    const handleFormData = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control
    } = useForm();

    // total original price
    const cartTotal = cart.map(item => {
        return item.originalPrice * item.quantity;
    });

    const calculateCartTotal = calculateTotal(cartTotal);
    const displayCartTotal = displayMoney(calculateCartTotal);


    // total discount
    const cartDiscount = cart.map(item => {
        return (item.originalPrice - item.finalPrice) * item.quantity;
    });

    const calculateCartDiscount = calculateTotal(cartDiscount);
    const displayCartDiscount = displayMoney(calculateCartDiscount);


    // // final total amount
    const totalAmount = calculateCartTotal - calculateCartDiscount;
    const displayTotalAmount = displayMoney(totalAmount);

    const cartcheckout = {
        totalprice: displayTotalAmount,
        cartitems: cart,
        originalprice: displayCartTotal,
        discount: displayCartDiscount,
        delivery: "Free"
    }

    const onCheckoutLogin = async (data) => {
        formData.role = 2
        AuthApi.Login(formData)
            .then((response) => {
                if (response.status === 200) {
                    setisForm(false)
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'success',
                        title: response.data.message
                    });
                    return setProfile(response);
                }
                else {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: response.data.message
                    });
                    // setError(response.data.message);
                }
            })
            .catch((error) => {

                if (error.response.status === 400 && error.response.data.email) {

                    return setError({ ...error, email: error.response.data.email });
                }
                else if (error.response.status === 400 && error.response.data.password) {

                    return setError({ ...error, password: error.response.data.password });
                }
                else if (error.response.status === 400 && error.response.data.verify) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.verify
                    });

                }
                else {

                    return setError({ ...error, email: error.response.data.message });
                }
            });

        reset();

    }

    const setProfile = (response) => {
        let user = response.data.data;
        let token = response.data.token;
        setUser(user);
        setToken(token);
        localStorage.setItem("clientUser", user, 5000);
        localStorage.setItem("clientToken", token, 5000);
        return navigate("/checkout", { state: { cartcheckoutdata: cartcheckout } });
    };

    const checkoutpage = () => {
        return navigate("/checkout", { state: { cartcheckoutdata: cartcheckout } });
        // return <h1 className='Vignesh'><Checkout data={cartcheckout} /></h1>
    }

    return (
        <>
            <Helmet>
                <title>Cart - Vilam Ecommerce</title>
            </Helmet>
            <section id="cart" className="section">

                {isForm &&

                    <div className="backdrop">
                        <div className="backdrop">
                            <div className="modal_centered">

                                <form id="edit_form" ref={formRef} onSubmit={handleSubmit(onCheckoutLogin)}>

                                    {/*===== Form-Header =====*/}
                                    <div className="form_head">
                                        <h2>Login</h2>
                                        {/* <p>
                                            New to Vilam Ecommerce ?
                                            &nbsp;&nbsp;
                                            <button type="button" onClick={handleIsSignupVisible}>
                                                Create an account
                                            </button>
                                        </p> */}
                                    </div>

                                    {/*===== Form-Body =====*/}
                                    <div className="form_body">

                                        <div className="input_box">
                                            <input
                                                type="email"
                                                name="email"
                                                className="input_field"
                                                // value={inputValues.mail || ''}
                                                onChange={handleFormData}
                                            // required
                                            />
                                            <label className="input_label">Email</label>
                                            {<span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{error.email}</span>}
                                        </div>

                                        <div className="input_box">
                                            <input
                                                type="password"
                                                name="password"
                                                className="input_field"
                                                // value={inputValues.password || ''}
                                                onChange={handleFormData}
                                            // required
                                            />
                                            <label className="input_label">Password</label>
                                            {<span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{error.password}</span>}
                                        </div>

                                        <button
                                            type="submit"
                                            className="btn login_btn"
                                        >
                                            Login
                                        </button>

                                    </div>

                                    <div
                                        className="close_btn"
                                        title="Close"
                                        onClick={() => setisForm(false)}
                                    >
                                        &times;
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>

                }

                <div className="container">
                    {
                        cartQuantity === 0 ? (
                            <EmptyView
                                icon={<BsCartX />}
                                msg="Your Cart is Empty"
                                link="/all-products"
                                btnText="Start Shopping"
                            />
                        ) : (
                            <div className="wrapper cart_wrapper">
                                <div className="cart_left_col">
                                    {
                                        cart.map((item) => {

                                            const newPrice = displayMoney(item.finalPrice);
                                            const oldPrice = displayMoney(item.originalPrice);

                                            return (

                                                <div className="cart_item" key={item.id}>
                                                    <figure className="cart_item_img">
                                                        <Link to={`${item.path}${item.id}`}>
                                                            {item.images &&
                                                                <ProductImage src={item.images[0]} alt={item.title} />
                                                            }
                                                        </Link>
                                                    </figure>
                                                    <div className="cart_item_info">
                                                        <div className="cart_item_head">
                                                            <h4 className="cart_item_title">
                                                                <Link to={`/product-details/${item.id}`}>{item.title} {item.info}</Link>
                                                            </h4>
                                                            <div className="cart_item_del">
                                                                <span onClick={() => removeItem(item)}>
                                                                    <TbTrash />
                                                                </span>
                                                                <div className="tooltip">Remove Item</div>
                                                            </div>
                                                        </div>

                                                        <h2 className="cart_item_price">
                                                            {newPrice} &nbsp;
                                                            <small><del>{oldPrice}</del></small>
                                                        </h2>

                                                        <QuantityBox itemId={item} itemQuantity={item.quantity} />
                                                    </div>
                                                </div>

                                            );

                                        }

                                        )
                                    }
                                </div>

                                <div className="cart_right_col">
                                    <div className="order_summary">
                                        <h3>
                                            Order Summary &nbsp;
                                            ( {cartQuantity} {cartQuantity > 1 ? 'items' : 'item'} )
                                        </h3>

                                        {/* {
                                            cart.map((item) => {

                                                const cartDiscount = (item.originalPrice - item.finalPrice) * item.quantity
                                                const calculateCartDiscount = calculateTotal(cartDiscount);
                                                const totalAmount = calculateCartTotal - calculateCartDiscount;
                                                const displayTotalAmount = displayMoney(totalAmount);
                                                const displayCartDiscount = displayMoney(calculateCartDiscount); */}

                                        {/* return ( */}
                                        <div className="order_summary_details">
                                            <div className="price">
                                                <span>Original Price</span>
                                                <b>{displayCartTotal}</b>
                                            </div>
                                            <div className="discount">
                                                <span>Discount</span>
                                                <b>- {displayCartDiscount}</b>
                                            </div>
                                            <div className="delivery">
                                                <span>Delivery</span>
                                                <b>Free</b>
                                            </div>
                                            <div className="separator"></div>
                                            <div className="total_price">
                                                <b><small>Total Price</small></b>
                                                <b>{displayTotalAmount}</b>
                                            </div>
                                        </div>
                                        {/* ); */}
                                        {/*      }
                                             )
                                         } */}

                                        {(!user || !token || token === "") ?
                                            <button type="button" onClick={() => setisForm(true)} className="btn checkout_btn">For Checkout Please Login</button>
                                            :
                                            <button type="button" onClick={checkoutpage} className="btn checkout_btn">Checkout</button>
                                        }
                                    </div>
                                </div>
                            </div>
                        )
                    }
                </div>
            </section>
        </>
    );
};

export default Cart;