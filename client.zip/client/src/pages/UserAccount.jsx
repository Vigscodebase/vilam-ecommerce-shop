import React, { useState, useEffect, useRef, useContext } from 'react';
import { Helmet } from "react-helmet";
import AuthApi from "../api/auth"
import { useAuth } from "../contexts/auth/authContext"
import Swal from 'sweetalert2'
import commonContext from "../contexts/common/commonContext"
import { useForm } from "react-hook-form";
import useOutsideClose from "../hooks/useOutsideClose"
import useScrollDisable from "../hooks/useScrollDisable"
import { Formik } from 'formik';

const UserAccount = () => {

    const [image, setImage] = useState({ preview: '', data: '' })
    const [isForm, setisForm] = useState(false)
    // const { isFormOpen, toggleForm } = useContext(commonContext);
    const { user } = useAuth();
    const { token } = useAuth();
    const imageRef = useRef()
    const formRef = useRef()
    const [usrobj, setUsrobj] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        image: ""
    });
    const [formData, setFormData] = useState({});
    const { setUser } = useAuth();

    const handleFormData = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const onChangeHandler = (e) => {
        const img = {
            preview: URL.createObjectURL(imageRef.current.files[0]),
            data: e.target.files[0],
        }
        setImage(img)
    }

    useEffect(() => {

        if (user || token || !token === "") {
            fetcSingleUser()
        }

    }, []);

    const fetcSingleUser = () => {

        AuthApi.GetSingleUser(user)
            .then((response) => {
                setUsrobj({
                    name: response.data.data.name,
                    email: response.data.data.email,
                    phone: response.data.data.phone,
                    address: response.data.data.address,
                    image: response.data.data.image
                })
            })

    }

    const onImgSubmit = async (e) => {

        e.preventDefault()
        let formData = new FormData()
        formData.append('usr_prof', image.data)

        AuthApi.UpdateUserImg(formData, user)
            .then((response) => {

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'success',
                    title: response.data.message
                });
                window.location.href = "/user-account"
            })
            .catch((error) => {
                if (error.response) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });

                }

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'error',
                    title: "There has been an error."
                });

            });

    }

    const handleChange = (e) => {
        console.log(formData)
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control
    } = useForm({
        // mode: "onChange",
        // defaultValues
    });

    useOutsideClose(formRef, () => {
        setisForm(false);
    });

    useScrollDisable(isForm);

    const onProfileChange = (data) => {
        const formData = data

        AuthApi.UpdateUserImg(formData, user)
            .then((response) => {

                return setProfile(response);
            })
            .catch((error) => {
                if (error.response) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });

                }

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'error',
                    title: "There has been an error."
                });

            });
    }

    const setProfile = (response) => {
        let user = response.data.data;
        let token = response.data.token;
        console.log(token)
        if (token != null & token != "") {
            localStorage.removeItem("clientUser");
            localStorage.removeItem("clientToken");

            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 5000,
                timerProgressBar: true
            });

            Toast.fire({
                icon: 'success',
                title: "User Profile Updated Successfully"
            });

            window.location.href = "/"

        }
        else {
            localStorage.setItem("clientUser", user, 5000);
            localStorage.setItem("clientToken", token, 5000);

            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 5000,
                timerProgressBar: true
            });

            Toast.fire({
                icon: 'success',
                title: "User Profile Updated Successfully"
            });

            window.location.href = "/user-account"
        }

        // return window.location.href = "/";
    };

    const toggleEditAddress = () => {
        setisForm(true);
    }

    return (
        <main>
            <Helmet>
                <title>Account - Vilam Ecommerce</title>
            </Helmet>

            <section id="product_details">
                <form onSubmit={onImgSubmit} >
                    <input type="file" name="usr_prof" onChange={onChangeHandler} ref={imageRef} />
                    <img src={image.preview} width={85} />
                    <button type="submit" className="btn" style={{ marginTop: "20px" }}>Save Image</button>
                </form>

                {

                    isForm && (

                        <div className="backdrop">

                            <div className="backdrop">
                                <div className="modal_centered">

                                    <form id="edit_form" ref={formRef} onSubmit={handleSubmit(onProfileChange)}>

                                        {/*===== Form-Header =====*/}
                                        <div className="form_head">
                                            <h2>Edit Your Profile</h2>
                                            {/* <p>
                                                Already have an account ?
                                                &nbsp;&nbsp;
                                                <button type="button">
                                                    Login
                                                </button>
                                            </p> */}
                                        </div>

                                        {/*===== Form-Body =====*/}
                                        <div className="form_body">

                                            <div className="input_box">
                                                <input
                                                    type="text"
                                                    name="name"
                                                    className="input_field"
                                                    defaultValue={usrobj.name}
                                                    // value={inputValues.username || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("name", {
                                                        // required: "Username Required",
                                                        pattern: {
                                                            value: /^[A-Za-z][A-Za-z0-9_]{3,29}$/,
                                                            message: "Entered value does not match username format"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Username</label>
                                                {errors.name && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.name.message}</span>}
                                            </div>

                                            <div className="input_box">
                                                <input
                                                    type="email"
                                                    name="email"
                                                    className="input_field"
                                                    defaultValue={usrobj.email}
                                                    // value={inputValues.mail || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("email", {
                                                        // required: "Email Required",
                                                        pattern: {
                                                            value: /[a-z0-9_]+@[a-z]+\.[a-z]{2,3}/,
                                                            message: "Entered value does not match email format"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Email</label>
                                                {errors.email && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.email.message}</span>}
                                            </div>

                                            <div className="input_box">
                                                <input
                                                    type="number"
                                                    name="phone"
                                                    className="input_field"
                                                    defaultValue={usrobj.phone}
                                                    // value={inputValues.username || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("phone", {
                                                        // required: "Mobile Number Required",
                                                        pattern: {
                                                            value: /^([0-9]{5})[-. ]?([0-9]{5})$/,
                                                            message: "Entered value does not match mobile number format"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Phone</label>
                                                {errors.phone && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.phone.message}</span>}
                                            </div>

                                            {/* <div className="input_box">
                                                <input
                                                    type="password"
                                                    name="password"
                                                    className="input_field"
                                                    // value={inputValues.password || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("password", {
                                                        required: "Password Required",
                                                        pattern: {
                                                            value: /((?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{6,}))|((?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9])(?=.{8,}))/,
                                                            message: "Password should have six characters, numeric digit & symbols"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Password</label>
                                                {errors.password && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.password.message}</span>}
                                            </div> */}

                                            <div className="input_box">
                                                <input
                                                    type="text"
                                                    name="adrdress"
                                                    className="input_field"
                                                    defaultValue={usrobj.address}
                                                    // value={inputValues.password || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("address")}
                                                />
                                                <label className="input_label">Address</label>
                                            </div>

                                            <button
                                                type="submit"
                                                className="btn login_btn"
                                            >
                                                Save
                                            </button>

                                        </div>

                                        <div
                                            className="close_btn"
                                            title="Close"
                                            onClick={() => setisForm(false)}
                                        >
                                            &times;
                                        </div>

                                    </form>

                                    {/* <Formik
                                        initialValues={{ name: usrobj.name, email: usrobj.email, phoneInputWithCountrySelect: usrobj.phone, address: usrobj.address }}
                                        enableReinitialize={true}

                                        valuseridate={values => {

                                            const errors = {};

                                            if (!values.name) {
                                                errors.name = 'Username Required'
                                            }
                                            else if (
                                                !/^[A-Za-z][A-Za-z0-9_]{3,29}$/.test(values.name)
                                            ) {
                                                errors.name = 'Entered value does not match username format';
                                            }

                                            if (!values.email) {
                                                errors.email = 'Email Required'
                                            }
                                            else if (
                                                !/[a-z0-9_]+@[a-z]+\.[a-z]{2,3}/.test(values.email)
                                            ) {
                                                errors.email = 'Entered value does not match email format';
                                            }

                                            if (!values.phoneInputWithCountrySelect) {
                                                errors.phoneInputWithCountrySelect = 'Mobile Number Required'
                                            }
                                            else if (
                                                !/^([0-9]{5})[-. ]?([0-9]{5})$/.test(values.phoneInputWithCountrySelect)
                                            ) {
                                                errors.phoneInputWithCountrySelect = 'Entered value does not match mobile number format';
                                            }

                                            return errors;

                                        }}

                                        onSubmit={(values, { setSubmitting }) => {
                                            console.log(values)
                                        }}
                                    > */}
                                    {
                                        // ({
                                        //     values,
                                        //     errors,
                                        //     touched,
                                        //     handleChange,
                                        //     handleBlur,
                                        //     handleSubmit,
                                        //     isSubmitting,
                                        //     resetForm
                                        // }) =>
                                        // (
                                        //     <form id="edit_form" onSubmit={handleSubmit}>

                                        //         /*===== Form-Header =====*/
                                        //         <div className="form_head">
                                        //             <h2>Edit Your Profile</h2>
                                        //             <p>
                                        //     Already have an account ?
                                        //     &nbsp;&nbsp;
                                        //     <button type="button" onClick={handleIsSignupVisible}>
                                        //         Login
                                        //     </button>
                                        // </p>
                                        //         </div>

                                        //         /*===== Form-Body =====*/
                                        //         <div className="form_body">

                                        //             <div className="input_box">
                                        //                 <input
                                        //                     type="text"
                                        //                     name="name"
                                        //                     className="input_field"
                                        //                     value={usrobj.name}
                                        //                     onChange={handleChange}
                                        //                     onBlur={handleBlur}
                                        //                 value={inputValues.username || ''}
                                        //                 required
                                        //                 />
                                        //                 <label className="input_label">Username</label>
                                        //                 <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.name && touched.name && errors.name}</span>
                                        //             </div>

                                        //             <div className="input_box">
                                        //                 <input
                                        //                     type="email"
                                        //                     name="email"
                                        //                     className="input_field"
                                        //                     onChange={handleChange}
                                        //                     onBlur={handleBlur}
                                        //                     value={inputValues.mail || ''}
                                        //                     onChange={handleChange}
                                        //                     required
                                        //                     value={usrobj.email}
                                        //                 />
                                        //                 <label className="input_label">Email</label>
                                        //                 <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.email && touched.email && errors.email}</span>
                                        //             </div>

                                        //             <div className="input_box">
                                        //                 <input
                                        //                     type="number"
                                        //                     name="phoneInputWithCountrySelect"
                                        //                     className="input_field"
                                        //                     onChange={handleChange}
                                        //                     onBlur={handleBlur}
                                        //                     value={inputValues.username || ''}
                                        //                     onChange={handleChange}
                                        //                     required
                                        //                     value={usrobj.phone}
                                        //                 />
                                        //                 <label className="input_label">Phone</label>
                                        //                 <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.phoneInputWithCountrySelect && touched.phoneInputWithCountrySelect && errors.phoneInputWithCountrySelect}</span>
                                        //             </div>

                                        //             <div className="input_box">
                                        //                 <input
                                        //                     type="text"
                                        //                     name="address"
                                        //                     className="input_field"
                                        //                     onChange={handleChange}
                                        //                     onBlur={handleBlur}
                                        //                     value={inputValues.password || ''}
                                        //                     onChange={handleChange}
                                        //                     required
                                        //                     value={usrobj.address}
                                        //                 />
                                        //                 <label className="input_label">Address</label>
                                        //             </div>

                                        //             <button
                                        //                 type="submit"
                                        //                 className="btn login_btn"
                                        //             >
                                        //                 Save
                                        //             </button>

                                        //         </div>

                                        //         <div
                                        //             className="close_btn"
                                        //             title="Close"
                                        //             onClick={() => setisForm(false)}
                                        //         >
                                        //             &times;
                                        //         </div>

                                        //     </form>
                                        // )
                                    }
                                    {/* </Formik> */}

                                </div>
                            </div>

                        </div>
                    )
                }
                <div id="account_form" style={{ marginTop: "90px" }}>
                    <h1 style={{ backgroundColor: "black", paddingLeft: "87px", paddingBottom: "8px" }}>Account Details</h1>
                    <img src={`/images/user_images/${usrobj.image}`} style={{ verticalAlign: "middle", width: "110px", height: "110px", borderRadius: "50%" }} />
                    <div style={{ display: "flex", backgroundColor: "black" }}>

                        <div>Name :</div>
                        <div style={{ marginLeft: "11px" }}>{usrobj.name}</div>

                    </div>

                    <div style={{ display: "flex", backgroundColor: "black" }}>

                        <div>Email :</div>
                        <div style={{ marginLeft: "11px" }}>{usrobj.email}</div>


                    </div>
                    <div style={{ display: "flex", backgroundColor: "black" }}>

                        <div>Phone :</div>
                        <div style={{ marginLeft: "11px" }}>{usrobj.phone}</div>

                    </div>
                    <div style={{ display: "flex", backgroundColor: "black" }}>

                        <div>Address :</div>
                        <div style={{ marginLeft: "11px" }}>{usrobj.address}</div>

                    </div>

                    {/* {usrobj.address === "" && */}
                    <button type="button" className="btn" style={{ marginTop: "20px" }} onClick={toggleEditAddress}>Edit Profile Add Address</button>
                    {/* } */}

                </div>

            </section>
        </main>
    );

}

export default UserAccount