import { useLocation } from 'react-router-dom';
import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Helmet } from "react-helmet";
import AuthApi from "../api/auth"
import RazorPayApi from "../api/razorpay"
import { useAuth } from "../contexts/auth/authContext"
import Swal from 'sweetalert2'
import { useForm } from "react-hook-form";
import razorpayicon from "../assets/images/razorpayicon.png"
import ProductImage from '../components/common/ProductImage';

const Checkout = () => {

    const location = useLocation();
    const navigate = useNavigate();
    const [cartdetail, setCartDetail] = React.useState(false)
    const [buydetail, setBuyDetail] = React.useState(false)
    const [usrobj, setUsrobj] = React.useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        image: ""
    });
    const { user } = useAuth();
    const [cartdata, setCartData] = React.useState({})
    const [buydata, setBuyData] = React.useState({})
    const [isForm, setisForm] = React.useState(false)
    const [formData, setFormData] = React.useState({});
    const [loader, setLoader] = React.useState(false)
    const formRef = React.useRef()

    React.useEffect(() => {

        if (location.state === null) {
            window.location.href = "/";
        }
        else {

            if (Object.keys(location.state)[0] === "cartcheckoutdata") {
                setCartData(location.state.cartcheckoutdata)
                setCartDetail(true)
            }
            else if (Object.keys(location.state)[0] === "buycheckoutdata") {
                setBuyData(location.state.buycheckoutdata)
                setBuyDetail(true)
            }
            else {
                window.location.href = "/"
            }

        }

        fetcSingleUser()

    }, []);
    // console.log(buydata)
    // console.log(cartdata)

    const fetcSingleUser = () => {

        AuthApi.GetSingleUser(user)
            .then((response) => {
                setUsrobj({
                    name: response.data.data.name,
                    email: response.data.data.email,
                    phone: response.data.data.phone,
                    address: response.data.data.address,
                    image: response.data.data.image
                })
            })

    }

    const toggleEditAddress = () => {
        setisForm(true);
    }

    const handleFormData = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control
    } = useForm({
        // mode: "onChange",
        // defaultValues
    });

    const onAddressChange = (data) => {
        const formData = data

        AuthApi.UpdateUserImg(formData, user)
            .then((response) => {

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'success',
                    title: response.data.message
                });
                setisForm(false);
                window.location.href = "/checkout"
            })
            .catch((error) => {
                if (error.response) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });

                }

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'error',
                    title: "There has been an error."
                });

            });
    }

    const razorpaymentCart = () => {

        var carttotalamount = cartdata.totalprice[0];
        var currencyamount = carttotalamount.slice(1);
        var validamount = currencyamount.replace(/[^a-zA-Z0-9 ]/g, '');
        var razorpayamount = { ordertotalamount: validamount }

        RazorPayApi.CreateOrder(razorpayamount)
            .then((response) => {
                const orderresponse = response.data.razorpayorderresponse
                setLoader(true)
                document.body.style.overflow = "hidden"
                Razorpay(orderresponse)
                // window.location.href = "/checkout"
            })
            .catch((error) => {
                if (error.response) {
                    console.log(error.response)
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });

                }

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'error',
                    title: "There has been an error."
                });

            });

    }

    const razorpaymentBuy = () => {

        var carttotalamount = buydata.orgprice[0];
        var currencyamount = carttotalamount.slice(1);
        var validamount = currencyamount.replace(/[^a-zA-Z0-9 ]/g, '');
        var razorpayamount = { ordertotalamount: validamount }

        RazorPayApi.CreateOrder(razorpayamount)
            .then((response) => {
                const orderresponse = response.data.razorpayorderresponse
                setLoader(true)
                document.body.style.overflow = "hidden"
                BuyRazorpay(orderresponse)
                // window.location.href = "/checkout"
            })
            .catch((error) => {
                if (error.response) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });

                }

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'error',
                    title: "There has been an error."
                });

            });


    }

    const Razorpay = (orderresponse) => {

        const orderId = orderresponse.id
        const usr_address = usrobj.address
        const usr_email = usrobj.email
        const usr_name = usrobj.name

        try {
            const options = {
                key: "rzp_test_rkrPh7XYff82v4",
                amount: orderresponse.amount,
                currency: "INR",
                name: "Vilam Ecommerce",
                // description: "Test",
                image: razorpayicon,
                order_id: orderId,
                prefill: {
                    name: usrobj.name,
                    email: usrobj.email,
                    contact: usrobj.phone,
                },
                notes: {
                    address: "Razorpay Corporate Office"
                },
                theme: {
                    color: "#d00404",
                },
                handler: async function (response) {

                    const reqorderresponse = { order_response: response, email: usr_email, cartdata: cartdata, buydata: buydata, address: usr_address, name: usr_name }
                    RazorPayApi.PaymentVerification(reqorderresponse)
                        .then((response) => {
                            const data = {
                                address: response.data.address,
                                cart: response.data.cart,
                                orderid: response.data.orderid
                            }
                            localStorage.removeItem("cart");

                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 5000,
                                timerProgressBar: true
                            });

                            Toast.fire({
                                icon: 'success',
                                title: response.data.message
                            });
                            // console.log(data)

                            //                             return navigate("/thank-you", { state: { cartcheckoutdata: data } });
                            window.location.href = "/all-products"
                        })
                        .catch((error) => {
                            if (error.response) {

                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 5000,
                                    timerProgressBar: true
                                });

                                Toast.fire({
                                    icon: 'error',
                                    title: error.response.data.message
                                });

                            }
                            else if (error.response.status === 400) {

                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 5000,
                                    timerProgressBar: true
                                });

                                Toast.fire({
                                    icon: 'error',
                                    title: error.response.data.message
                                });

                            }

                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 5000,
                                timerProgressBar: true
                            });

                            Toast.fire({
                                icon: 'error',
                                title: "There has been an error."
                            });

                        });

                }
            }

            const razor = new window.Razorpay(options);
            razor.on('payment.failed', function (response) {
                alert(response.error.code);
                alert(response.error.description);
                alert(response.error.source);
                alert(response.error.step);
                alert(response.error.reason);
                alert(response.error.metadata.order_id);
                alert(response.error.metadata.payment_id);
            });
            setLoader(false)
            document.body.style.overflow = "auto"
            razor.open();
        } catch (e) {
            return e;
        }

    }

    const BuyRazorpay = (orderresponse) => {

        const orderId = orderresponse.id
        const usr_address = usrobj.address
        const usr_email = usrobj.email
        const usr_name = usrobj.name

        try {
            const options = {
                key: "rzp_test_rkrPh7XYff82v4",
                amount: orderresponse.amount,
                currency: "INR",
                name: "Vilam Ecommerce",
                // description: "Test",
                image: razorpayicon,
                order_id: orderId,
                prefill: {
                    name: usrobj.name,
                    email: usrobj.email,
                    contact: usrobj.phone,
                },
                notes: {
                    address: "Razorpay Corporate Office"
                },
                theme: {
                    color: "#d00404",
                },
                handler: async function (response) {

                    const reqorderresponse = { order_response: response, email: usr_email, buydata: buydata, address: usr_address, name: usr_name }
                    RazorPayApi.BuyPaymentVerification(reqorderresponse)
                        .then((response) => {
                            const data = {
                                address: response.data.address,
                                buy: response.data.buy,
                                orderid: response.data.orderid
                            }

                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 5000,
                                timerProgressBar: true
                            });

                            Toast.fire({
                                icon: 'success',
                                title: response.data.message
                            });
                            // console.log(data)

                            //                             return navigate("/thank-you", { state: { cartcheckoutdata: data } });
                            window.location.href = "/all-products"
                        })
                        .catch((error) => {
                            if (error.response) {

                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 5000,
                                    timerProgressBar: true
                                });

                                Toast.fire({
                                    icon: 'error',
                                    title: error.response.data.message
                                });

                            }
                            else if (error.response.status === 400) {

                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 5000,
                                    timerProgressBar: true
                                });

                                Toast.fire({
                                    icon: 'error',
                                    title: error.response.data.message
                                });

                            }

                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 5000,
                                timerProgressBar: true
                            });

                            Toast.fire({
                                icon: 'error',
                                title: "There has been an error."
                            });

                        });

                }
            }

            const razor = new window.Razorpay(options);
            razor.on('payment.failed', function (response) {
                alert(response.error.code);
                alert(response.error.description);
                alert(response.error.source);
                alert(response.error.step);
                alert(response.error.reason);
                alert(response.error.metadata.order_id);
                alert(response.error.metadata.payment_id);
            });
            setLoader(false)
            document.body.style.overflow = "auto"
            razor.open();
        } catch (e) {
            return e;
        }

    }

    return (
        <section id="cart" className="section">

            <Helmet>
                <title>Checkout - Vilam Ecommerce</title>
            </Helmet>

            {

                isForm && (

                    <div className="backdrop">

                        <div className="backdrop">
                            <div className="modal_centered">

                                <form id="edit_form" ref={formRef} onSubmit={handleSubmit(onAddressChange)}>

                                    {/*===== Form-Header =====*/}
                                    <div className="form_head">
                                        <h2>Edit Address</h2>
                                    </div>

                                    {/*===== Form-Body =====*/}
                                    <div className="form_body">

                                        <div className="input_box">
                                            <input
                                                type="text"
                                                name="adrdress"
                                                className="input_field"
                                                defaultValue={usrobj.address}
                                                // value={inputValues.password || ''}
                                                onChange={handleFormData}
                                                // required
                                                {...register("address")}
                                            />
                                            <label className="input_label">Address</label>
                                        </div>

                                        <button
                                            type="submit"
                                            className="btn login_btn"
                                        >
                                            Save
                                        </button>

                                    </div>

                                    <div
                                        className="close_btn"
                                        title="Close"
                                        onClick={() => setisForm(false)}
                                    >
                                        &times;
                                    </div>

                                </form>

                            </div>
                        </div>

                    </div>
                )
            }

            <div className="container">

                {cartdetail &&
                    <div className="wrapper cart_wrapper">

                        <div className="cart_left_col">
                            <h1>Shipping Address</h1>
                            <p style={{ marginTop: "20px" }}>{usrobj.address}</p>
                            <button style={{ marginTop: "20px" }} type="button" onClick={toggleEditAddress} className="btn">Change Address</button>
                        </div>

                        <div className="cart_right_col">
                            <div className="order_summary">
                                <h3>
                                    Order Summary &nbsp;
                                    ( {cartdata.cartitems.length} {'item'} )
                                </h3>
                                <div className="order_summary_details">
                                    <div className="price">
                                        <span>Original Price</span>
                                        <b>{cartdata.originalprice[0]}</b>
                                    </div>
                                    <div className="discount">
                                        <span>Discount</span>
                                        <b>- {cartdata.discount[0]}</b>
                                    </div>
                                    <div className="delivery">
                                        <span>Delivery</span>
                                        <b>{cartdata.delivery}</b>
                                    </div>
                                    <div className="separator"></div>
                                    <div className="total_price">
                                        <b><small>Total Price</small></b>
                                        <b>{cartdata.totalprice[0]}</b>
                                    </div>
                                </div>
                            </div>
                            <button type="button" className="btn checkout_btn" onClick={razorpaymentCart}>Pay Now</button>
                        </div>

                        <div className="cart_left_col">
                            <h1>Items</h1>
                            {
                                cartdata.cartitems.map(item => (
                                    <div style={{ borderBottom: "1px solid rgba(102, 102, 102, 0.6)" }} className="cart_item" key={item.id}>
                                        <figure className="cart_item_img">
                                            <Link to={`${item.path}${item.id}`}>
                                                {item.images &&
                                                    <ProductImage src={item.images[0]} alt={item.title} />
                                                }
                                            </Link>
                                        </figure>
                                        <div className="cart_item_info">
                                            <div className="cart_item_head">
                                                <Link to={`${item.path}${item.id}`}>{item.title}</Link>
                                            </div>
                                            <h2 className="cart_item_price">
                                                ₹{item.finalPrice} &nbsp;
                                                <small><del>₹{item.originalPrice}</del></small>
                                            </h2>
                                        </div>
                                    </div>
                                ))
                            }
                        </div>

                        {loader &&
                            <div className="backdrop">
                                <div className="backdrop">
                                    <div className="modal_centered">
                                        <img src={window.location.origin + "/loader/Loader_effect.gif"} />
                                    </div>
                                </div>
                            </div>
                        }

                    </div>
                }
                {buydetail &&
                    <div className="wrapper cart_wrapper">

                        <div className="cart_left_col">
                            <h1>Shipping Address</h1>
                            <p style={{ marginTop: "20px" }}>{usrobj.address}</p>
                            <button style={{ marginTop: "20px" }} type="button" onClick={toggleEditAddress} className="btn">Change Address</button>

                        </div>

                        <div className="cart_right_col">
                            <div className="order_summary">
                                <h3>
                                    Order Summary &nbsp;
                                    ( {1} {'item'} )
                                </h3>
                                <div className="order_summary_details">
                                    <div className="price">
                                        <span>Original Price</span>
                                        <b>{buydata.oldPrice}</b>
                                    </div>
                                    <div className="discount">
                                        <span>Discount</span>
                                        <b>- {buydata.discountprice[0]}</b>
                                    </div>
                                    <div className="delivery">
                                        <span>Delivery</span>
                                        <b>{buydata.delivery}</b>
                                    </div>
                                    <div className="separator"></div>
                                    <div className="total_price">
                                        <b><small>Total Price</small></b>
                                        <b>{buydata.orgprice}</b>
                                    </div>
                                </div>
                            </div>
                            <button type="button" className="btn checkout_btn" onClick={razorpaymentBuy}>Pay Now</button>
                        </div>

                        <div className="cart_left_col">
                            <h1>Items</h1>
                            <div style={{ borderBottom: "1px solid rgba(102, 102, 102, 0.6)" }} className="cart_item">
                                <figure className="cart_item_img">
                                    <Link to={`${buydata.path}${buydata.id}`}>
                                        <ProductImage src={buydata.prodimg} alt={buydata.prodtitle} />
                                    </Link>
                                </figure>
                                <div className="cart_item_info">
                                    <div className="cart_item_head">
                                        <Link to={`${buydata.path}${buydata.id}`}>{buydata.prodtitle}</Link>
                                    </div>
                                    <h2 className="cart_item_price">
                                        {buydata.orgprice} &nbsp;
                                        <small><del>{buydata.oldPrice}</del></small>
                                    </h2>
                                </div>
                            </div>
                        </div>

                    </div>
                }

            </div>

        </section>
    );

}

export default Checkout