import React, { useContext, useEffect, useState, useRef } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { IoMdStar, IoMdCheckmark } from 'react-icons/io';
import { MdError } from "react-icons/md";
import { calculateDiscount, displayMoney } from '../helpers/utils';
import useDocTitle from '../hooks/useDocTitle';
import useActive from '../hooks/useActive';
import cartContext from '../contexts/cart/cartContext';
import { useProducts } from '../contexts/products/productsContext';
import SectionsHead from '../components/common/SectionsHead';
import RelatedSlider from '../components/sliders/RelatedSlider';
import ProductSummary from '../components/product/ProductSummary';
import Services from '../components/common/Services';
import ProductImage from '../components/common/ProductImage';
import clsx from 'clsx';
import { Helmet } from "react-helmet";
import { useAuth } from "../contexts/auth/authContext"
import { useForm } from "react-hook-form";
import AuthApi from "../api/auth"
import Swal from 'sweetalert2'

const ProductDetails = () => {

    useDocTitle('Product Details');

    const { handleActive, activeClass } = useActive(0);

    const { addItem } = useContext(cartContext);

    const { productId } = useParams();

    // here the 'id' received has 'string-type', so converting it to a 'Number'
    // const prodId = parseInt(productId);

    // Products load asynchronously (see contexts/products/productsContext.js),
    // so on first render(s) `products` may still be empty and/or the id in
    // the URL may not match anything (bad link, deleted product, etc).
    // `product` used to be destructured straight away, which crashed the
    // page with "Cannot destructure property 'id' of undefined" whenever
    // that happened. Defaulting to `{}` keeps every hook below safe to call
    // unconditionally; the actual "still loading" / "not found" UI is
    // handled by the guard further down, after all hooks have run.
    const { products: productsData, loading: productsLoading } = useProducts();
    const product = productsData.find(item => item.id === productId);

    const { id, images = [], title, info, category, finalPrice, originalPrice, ratings, rateCount, quantity, path } = product || {};
    const [previewImg, setPreviewImg] = useState(images[0]);
    const [cartText, setcartText] = useState(false)
    const [disable, setDisable] = useState(false)
    const [active, setActive] = useState("inactive")
    const [isForm, setisForm] = useState(false)
    const formRef = useRef()
    const [error, setError] = useState({
        email: " ",
        password: " ",
        fatalError: " "
    });
    const [formData, setFormData] = useState({});
    const navigate = useNavigate();
    let { user, token, setUser, setToken } = useAuth();

    const handleFormData = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control
    } = useForm();

    // handling Add-to-cart
    const handleAddItem = () => {
        addItem(product);
        setcartText(true)
        setDisable(true);
        setActive("active")

        setTimeout(() => {
            setcartText(false)
            setDisable(false);
            setActive("inactive")
        }, 3000);

    };


    // setting the very-first image on re-render
    useEffect(() => {
        setPreviewImg(images[0]);
        handleActive(0);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [images]);


    // handling Preview image
    const handlePreviewImg = (i) => {
        setPreviewImg(images[i]);
        handleActive(i);
    };


    // calculating Prices
    const discountedPrice = originalPrice - finalPrice;
    const newPrice = displayMoney(finalPrice);
    const oldPrice = displayMoney(originalPrice);
    const savedPrice = displayMoney(discountedPrice);
    const savedDiscount = calculateDiscount(discountedPrice, originalPrice);

    const buycheckout = {
        prodtitle: title,
        prodimg: images[0],
        orgprice: newPrice,
        discountprice: savedPrice,
        delivery: "Free",
        path: path,
        id: id,
        oldPrice: oldPrice
    }

    const onBuyNowLogin = async (data) => {
        formData.role = 2
        AuthApi.Login(formData)
            .then((response) => {
                if (response.status === 200) {
                    setisForm(false)
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'success',
                        title: response.data.message
                    });
                    return setProfile(response);
                }
                else {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: response.data.message
                    });
                    // setError(response.data.message);
                }
            })
            .catch((error) => {

                if (error.response.status === 400 && error.response.data.email) {

                    return setError({ ...error, email: error.response.data.email });
                }
                else if (error.response.status === 400 && error.response.data.password) {

                    return setError({ ...error, password: error.response.data.password });
                }
                else if (error.response.status === 400 && error.response.data.verify) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.verify
                    });

                }
                else {

                    return setError({ ...error, email: error.response.data.message });
                }
            });

        reset();

    }

    const setProfile = (response) => {
        let user = response.data.data;
        let token = response.data.token;
        setUser(user);
        setToken(token);
        localStorage.setItem("clientUser", user, 5000);
        localStorage.setItem("clientToken", token, 5000);
        return navigate("/checkout", { state: { buycheckoutdata: buycheckout } });
    };

    const checkoutpage = () => {
        return navigate("/checkout", { state: { buycheckoutdata: buycheckout } });
    }

    // All hooks above have already run unconditionally (rules of hooks), so
    // it's safe to bail out of rendering here while products are still
    // loading, or if this id simply doesn't match a product.
    if (productsLoading) {
        return <p style={{ padding: '40px', textAlign: 'center' }}>Loading product...</p>;
    }

    if (!product) {
        return (
            <div style={{ padding: '40px', textAlign: 'center' }}>
                <p>Sorry, we couldn't find that product.</p>
                <Link to="/all-products">Browse all products</Link>
            </div>
        );
    }

    return (
        <>
            <Helmet>
                <title>Product Details - Vilam Ecommerce</title>
            </Helmet>
            <section id="product_details" className="section">

                {isForm &&

                    <div className="backdrop">
                        <div className="backdrop">
                            <div className="modal_centered">

                                <form id="edit_form" ref={formRef} onSubmit={handleSubmit(onBuyNowLogin)}>

                                    {/*===== Form-Header =====*/}
                                    <div className="form_head">
                                        <h2>Login</h2>
                                        {/* <p>
                        New to Vilam Ecommerce ?
                        &nbsp;&nbsp;
                        <button type="button" onClick={handleIsSignupVisible}>
                            Create an account
                        </button>
                    </p> */}
                                    </div>

                                    {/*===== Form-Body =====*/}
                                    <div className="form_body">

                                        <div className="input_box">
                                            <input
                                                type="email"
                                                name="email"
                                                className="input_field"
                                                // value={inputValues.mail || ''}
                                                onChange={handleFormData}
                                            // required
                                            />
                                            <label className="input_label">Email</label>
                                            {<span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{error.email}</span>}
                                        </div>

                                        <div className="input_box">
                                            <input
                                                type="password"
                                                name="password"
                                                className="input_field"
                                                // value={inputValues.password || ''}
                                                onChange={handleFormData}
                                            // required
                                            />
                                            <label className="input_label">Password</label>
                                            {<span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{error.password}</span>}
                                        </div>

                                        <button
                                            type="submit"
                                            className="btn login_btn"
                                        >
                                            Login
                                        </button>

                                    </div>

                                    <div
                                        className="close_btn"
                                        title="Close"
                                        onClick={() => setisForm(false)}
                                    >
                                        &times;
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>

                }

                <div className="container">
                    <div className="wrapper prod_details_wrapper">

                        {/*=== Product Details Left-content ===*/}
                        <div className="prod_details_left_col">
                            <div className="prod_details_tabs">
                                {
                                    images.map((img, i) => (
                                        <div
                                            key={i}
                                            className={`tabs_item ${activeClass(i)}`}
                                            onClick={() => handlePreviewImg(i)}
                                        >
                                            <ProductImage src={img} />
                                        </div>
                                    ))
                                }
                            </div>
                            <figure className="prod_details_img">
                                <ProductImage src={previewImg} />
                            </figure>
                        </div>

                        {/*=== Product Details Right-content ===*/}
                        <div className="prod_details_right_col">
                            <h1 className="prod_details_title">{title}</h1>
                            <h4 className="prod_details_info">{info}</h4>

                            <div className="prod_details_ratings">
                                <span className="rating_star">
                                    {
                                        [...Array(rateCount)].map((_, i) => <IoMdStar key={i} />)
                                    }
                                </span>
                                <span>|</span>
                                <span>{ratings} Ratings</span>
                            </div>

                            <div className="separator"></div>

                            <div className="prod_details_price">
                                <div className="price_box">
                                    <h2 className="price">
                                        {newPrice} &nbsp;
                                        <small className="del_price"><del>{oldPrice}</del></small>
                                    </h2>
                                    <p className="saved_price">You save: {savedPrice} ({savedDiscount}%)</p>
                                    <span className="tax_txt">(Inclusive of all taxes)</span>
                                </div>

                                {quantity > 1 &&
                                    <div className="badge">
                                        <span><IoMdCheckmark /> In Stock</span>
                                    </div>
                                }
                                {quantity == 1 &&
                                    <div className="badge">
                                        <span><IoMdCheckmark /> In Stock</span>
                                    </div>
                                }
                                {quantity == 0 &&
                                    <div className="badge-empty">
                                        <span><MdError /> Out Of Stock</span>
                                    </div>
                                }
                            </div>

                            {/* <div className="separator"></div>

                            <div className="prod_details_offers">
                                <h4>Offers and Discounts</h4>
                                <ul>
                                    <li>No Cost EMI on Credit Card</li>
                                    <li>Pay Later & Avail Cashback</li>
                                </ul>
                            </div> */}

                            <div className="separator"></div>

                            <div className="prod-detail-buttons">
                                {quantity == 1 &&
                                    <div className="prod_details_add_cart">
                                        <button
                                            type="button"
                                            className={clsx('btn products_btn', active)}
                                            onClick={handleAddItem}
                                            disabled={disable}
                                        >
                                            {cartText ? 'Adding' : ' Add to cart'}
                                        </button>
                                    </div>
                                }

                                {quantity == 1 &&

                                    <div className="prod_details_buy_btn">
                                        {user || token || !token === "" ?
                                            <button
                                                type="button"
                                                className="btn products_btn"
                                                onClick={checkoutpage}
                                            >
                                                Buy Now
                                            </button>
                                            :
                                            <button
                                                type="button"
                                                className="btn products_btn"
                                                onClick={() => setisForm(true)}
                                                style={{ paddingLeft: "0px", paddingRight: "0px" }}
                                            >
                                                Login To Buy
                                            </button>
                                        }
                                    </div>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <ProductSummary {...product} />

            <section id="related_products" className="section">
                <div className="container">
                    <SectionsHead heading="Related Products" />
                    <RelatedSlider category={category} />
                </div>
            </section>

            <Services />
        </>
    );
};

export default ProductDetails;