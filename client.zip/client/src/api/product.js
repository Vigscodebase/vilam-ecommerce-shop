import { axios, axiosFile } from "./axios/axiosinstance"

class ProductApi {

    static GetAllProducts = () => {
        return axios.get(`products/product-listing`);
    };

}

export default ProductApi;