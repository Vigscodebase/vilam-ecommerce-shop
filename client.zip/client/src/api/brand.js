import { axios, axiosFile } from "./axios/axiosinstance"

class BrandApi {

    static GetAllBrand = () => {
        return axios.get(`brands/brand-listing`);
    };

}

export default BrandApi;