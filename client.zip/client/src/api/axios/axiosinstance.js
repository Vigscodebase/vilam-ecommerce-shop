import Axios from "axios";

export const axios = Axios.create({
  baseURL: "/api/",
  headers: { "Content-Type": "application/json" },
});

export const axiosFile = Axios.create({
  baseURL: "/api/",
  headers: { "Content-Type": "multipart/form-data" },
});

export const axiosrazorpay = Axios.create({
  baseURL: "/api/",
});

axios.interceptors.request.use(
  (config) => {
    return Promise.resolve(config);
  },
  (error) => Promise.reject(error)
);

axios.interceptors.response.use(
  (response) => Promise.resolve(response),
  (error) => {
    return Promise.reject(error);
  }
);

axiosFile.interceptors.request.use(
  (config) => {
    return Promise.resolve(config);
  },
  (error) => Promise.reject(error)
);

axiosFile.interceptors.response.use(
  (response) => Promise.resolve(response),
  (error) => {
    return Promise.reject(error);
  }
);

axiosrazorpay.interceptors.request.use(
  (config) => {
    return Promise.resolve(config);
  },
  (error) => Promise.reject(error)
);

axiosrazorpay.interceptors.response.use(
  (response) => Promise.resolve(response),
  (error) => {
    return Promise.reject(error);
  }
);

// export default axios;
