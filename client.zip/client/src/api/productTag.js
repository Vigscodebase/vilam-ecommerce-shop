import { axios, axiosFile } from "./axios/axiosinstance"

class ProductTagApi {

    static GetAllProductTag = () => {
        return axios.get(`product-tags/product-tag-listing`);
    };

}

export default ProductTagApi;