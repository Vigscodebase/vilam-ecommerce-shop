import { axiosrazorpay } from "./axios/axiosinstance"

class RazorPayApi {

    static CreateOrder = (razorpayamount) => {
        return axiosrazorpay.post("razorpay/create-order", razorpayamount);
    };

    static PaymentVerification = (reqorderresponse) => {
        return axiosrazorpay.post("razorpay/payment-verification", reqorderresponse);
    };

    static BuyPaymentVerification = (reqorderresponse) => {
        return axiosrazorpay.post("razorpay/buy-payment-verification", reqorderresponse);
    };

}

export default RazorPayApi;