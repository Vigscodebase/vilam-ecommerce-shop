import { axios } from "./axios/axiosinstance"

class OrderApi {

    static GetSingleOrderById = (id) => {
        return axios.get(`orders/single-order/${id}`);
    };

}

export default OrderApi;