import { axios, axiosFile } from "./axios/axiosinstance"

class CategoryApi {

    static GetAllCategory = () => {
        return axios.get(`category/category-listing`);
    };

}

export default CategoryApi;