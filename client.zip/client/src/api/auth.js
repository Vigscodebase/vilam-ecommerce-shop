import { axios, axiosFile } from "./axios/axiosinstance"

class AuthApi {

    static Register = (data) => {
        return axios.post("user/add-user-account", data);
    };

    static VerifyEmail = () => {
        const curr_url = window.location.pathname;
        const curr_url_array = curr_url.split('/');
        const token_verify = curr_url_array.at(-1)
        return axios.get(`user/verify/${token_verify}`);
    };

    static Login = (data) => {
        return axios.post(`user/login`, data);
    };

    static GetSingleUser = (usrid) => {
        return axios.get(`user/single-user/${usrid}`);
    };

    static UpdateUserImg = (formdata, user) => {
        return axiosFile.patch(`user/user-profile-img/${user}`, formdata);
    };

}

export default AuthApi;