import React, { useContext, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import commonContext from '../../contexts/common/commonContext';
// import useForm from '../../hooks/useForm';
import useOutsideClose from '../../hooks/useOutsideClose';
import useScrollDisable from '../../hooks/useScrollDisable';
import Swal from 'sweetalert2'
import { useForm } from "react-hook-form";
import AuthApi from "../../api/auth"
// import AuthContext from '../../contexts/auth/authContext';
import { useAuth } from "../../contexts/auth/authContext";

const AccountForm = () => {

    const { isFormOpen, toggleForm } = useContext(commonContext);
    // const { inputValues, handleInputValues, handleFormSubmit } = useForm();
    const [formData, setFormData] = useState({});
    const formRef = useRef();
    // const { setUser, setToken } = useContext(AuthContext);
    const { setToken } = useAuth();
    const { setUser } = useAuth();
    const navigate = useNavigate();

    const [error, setError] = useState({
        email: " ",
        password: " ",
        fatalError: " "
    });

    const handleFormData = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control
    } = useForm();

    useOutsideClose(formRef, () => {
        toggleForm(false);
    });

    useScrollDisable(isFormOpen);

    const [isSignupVisible, setIsSignupVisible] = useState(false);

    // Signup-form visibility toggling
    const handleIsSignupVisible = () => {
        setIsSignupVisible(prevState => !prevState);
    };

    const onSignInSubmit = async (data) => {
        formData.role = 2

        AuthApi.Login(formData)
            .then((response) => {
                if (response.status === 200) {
                    toggleForm(false)
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'success',
                        title: response.data.message
                    });
                    return setProfile(response);
                }
                else {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: response.data.message
                    });
                    // setError(response.data.message);
                }
            })
            .catch((error) => {

                if (error.response.status === 400 && error.response.data.email) {

                    return setError({ ...error, email: error.response.data.email });
                }
                else if (error.response.status === 400 && error.response.data.password) {

                    return setError({ ...error, password: error.response.data.password });
                }
                else if (error.response.status === 400 && error.response.data.account) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.account
                    });

                }
                else if (error.response.status === 400 && error.response.data.verify) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.verify
                    });

                }
                else {

                    return setError({ ...error, email: error.response.data.message });
                }
            });

        reset();
    };

    const setProfile = (response) => {
        let user = response.data.data;
        let token = response.data.token;
        setUser(user);
        setToken(token);
        localStorage.setItem("clientUser", user, 5000);
        localStorage.setItem("clientToken", token, 5000);
        //return navigate("/");
    };

    const onSignUpSubmit = async (data) => {
        const formdata = data
        formdata.role = 2

        AuthApi.Register(formdata)
            .then((response) => {
                if (response.data.success) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'success',
                        title: response.data.success
                    });
                    toggleForm(false)
                    // return navigate("/authentication/sign-in");
                } else {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: response.data.message
                    });
                    // setError(response.data.message);
                }
            })
            .catch((error) => {
                if (error.response) {

                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 5000,
                        timerProgressBar: true
                    });

                    Toast.fire({
                        icon: 'error',
                        title: error.response.data.message
                    });

                    // return setError(error.response.data.message);
                }

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true
                });

                Toast.fire({
                    icon: 'error',
                    title: "There has been an error."
                });
                //   return setError("There has been an error.");
            });

        reset();
    };

    return (
        <>
            {
                isFormOpen && (
                    <div className="backdrop">
                        {isSignupVisible ?

                            <div className="backdrop">
                                <div className="modal_centered">
                                    <form id="account_form" ref={formRef} onSubmit={handleSubmit(onSignUpSubmit)}>

                                        {/*===== Form-Header =====*/}
                                        <div className="form_head">
                                            <h2>Signup</h2>
                                            <p>
                                                Already have an account ?
                                                &nbsp;&nbsp;
                                                <button type="button" onClick={handleIsSignupVisible}>
                                                    Login
                                                </button>
                                            </p>
                                        </div>

                                        {/*===== Form-Body =====*/}
                                        <div className="form_body">

                                            <div className="input_box">
                                                <input
                                                    type="text"
                                                    name="name"
                                                    className="input_field"
                                                    // value={inputValues.username || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("name", {
                                                        required: "Username Required",
                                                        pattern: {
                                                            value: /^[A-Za-z][A-Za-z0-9_]{3,29}$/,
                                                            message: "Entered value does not match username format"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Username</label>
                                                {errors.name && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.name.message}</span>}
                                            </div>

                                            <div className="input_box">
                                                <input
                                                    type="email"
                                                    name="email"
                                                    className="input_field"
                                                    // value={inputValues.mail || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("email", {
                                                        required: "Email Required",
                                                        pattern: {
                                                            value: /[a-z0-9_]+@[a-z]+\.[a-z]{2,3}/,
                                                            message: "Entered value does not match email format"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Email</label>
                                                {errors.email && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.email.message}</span>}
                                            </div>

                                            <div className="input_box">
                                                <input
                                                    type="number"
                                                    name="phoneInputWithCountrySelect"
                                                    className="input_field"
                                                    // value={inputValues.username || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("phoneInputWithCountrySelect", {
                                                        required: "Mobile Number Required",
                                                        pattern: {
                                                            value: /^([0-9]{5})[-. ]?([0-9]{5})$/,
                                                            message: "Entered value does not match mobile number format"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Phone</label>
                                                {errors.phoneInputWithCountrySelect && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.phoneInputWithCountrySelect.message}</span>}
                                            </div>

                                            <div className="input_box">
                                                <input
                                                    type="password"
                                                    name="password"
                                                    className="input_field"
                                                    // value={inputValues.password || ''}
                                                    onChange={handleFormData}
                                                    // required
                                                    {...register("password", {
                                                        required: "Password Required",
                                                        pattern: {
                                                            value: /((?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{6,}))|((?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9])(?=.{8,}))/,
                                                            message: "Password should have six characters, numeric digit & symbols"
                                                        }
                                                    })}
                                                />
                                                <label className="input_label">Password</label>
                                                {errors.password && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.password.message}</span>}
                                            </div>

                                            <button
                                                type="submit"
                                                className="btn login_btn"
                                            >
                                                Signup
                                            </button>

                                        </div>

                                        <div
                                            className="close_btn"
                                            title="Close"
                                            onClick={() => toggleForm(false)}
                                        >
                                            &times;
                                        </div>

                                    </form>
                                </div>
                            </div>

                            :

                            <div className="backdrop">
                                <div className="modal_centered">
                                    <form id="account_form" ref={formRef} onSubmit={handleSubmit(onSignInSubmit)}>

                                        {/*===== Form-Header =====*/}
                                        <div className="form_head">
                                            <h2>Login</h2>
                                            <p>
                                                New to Vilam Ecommerce ?
                                                &nbsp;&nbsp;
                                                <button type="button" onClick={handleIsSignupVisible}>
                                                    Create an account
                                                </button>
                                            </p>
                                        </div>

                                        {/*===== Form-Body =====*/}
                                        <div className="form_body">

                                            <div className="input_box">
                                                <input
                                                    type="email"
                                                    name="email"
                                                    className="input_field"
                                                    // value={inputValues.mail || ''}
                                                    onChange={handleFormData}
                                                // required
                                                />
                                                <label className="input_label">Email</label>
                                                {<span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{error.email}</span>}
                                            </div>

                                            <div className="input_box">
                                                <input
                                                    type="password"
                                                    name="password"
                                                    className="input_field"
                                                    // value={inputValues.password || ''}
                                                    onChange={handleFormData}
                                                // required
                                                />
                                                <label className="input_label">Password</label>
                                                {<span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{error.password}</span>}
                                            </div>

                                            <button
                                                type="submit"
                                                className="btn login_btn"
                                            // onClick={onSignInSubmit}
                                            >
                                                Login
                                            </button>

                                        </div>

                                        <div
                                            className="close_btn"
                                            title="Close"
                                            onClick={() => toggleForm(false)}
                                        >
                                            &times;
                                        </div>

                                    </form>
                                </div>
                            </div>

                        }
                    </div>
                )

            }
        </>
    );
};

export default AccountForm;