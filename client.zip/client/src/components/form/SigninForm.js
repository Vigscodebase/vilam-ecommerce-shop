import React, { useContext, useRef, useState } from 'react';
import useOutsideClose from '../../hooks/useOutsideClose';
import commonContext from "../../contexts/common/commonContext"
import Swal from 'sweetalert2'
import { useForm } from "react-hook-form";
import AccountForm from "./AccountForm"

const SigninForm = () => {

    const [formData, setFormData] = useState({});
    const { toggleForm } = useContext(commonContext);
    const formRef = useRef();

    useOutsideClose(formRef, () => {
        toggleForm(false);
    });

    const handleFormData = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });

    };

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        control
    } = useForm();

    const onSignInSubmit = async (data) => {
        const formdata = data
        reset();
    };

    return (
        <div className="backdrop">
            <div className="modal_centered">
                <form id="account_form" ref={formRef} onSubmit={handleSubmit(onSignInSubmit)}>

                    {/*===== Form-Header =====*/}
                    <div className="form_head">
                        <h2>Login</h2>
                        <p>
                        New to Vilam Ecommerce ?
                            &nbsp;&nbsp;
                            <button type="button">
                            Create an account
                            </button>
                        </p>
                    </div>

                    {/*===== Form-Body =====*/}
                    <div className="form_body">

                        <div className="input_box">
                            <input
                                type="email"
                                name="mail"
                                className="input_field"
                                // value={inputValues.mail || ''}
                                onChange={handleFormData}
                                // required
                                {...register("mail", {
                                    required: "Email Required",
                                    pattern: {
                                        value: /[a-z0-9_]+@[a-z]+\.[a-z]{2,3}/,
                                        message: "Entered value does not match email format"
                                    }
                                })}
                            />
                            <label className="input_label">Email</label>
                            {errors.mail && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.mail.message}</span>}
                        </div>

                        <div className="input_box">
                            <input
                                type="password"
                                name="password"
                                className="input_field"
                                // value={inputValues.password || ''}
                                onChange={handleFormData}
                                // required
                                {...register("password", {
                                    required: "Password Required",
                                    pattern: {
                                        value: /((?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{6,}))|((?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9])(?=.{8,}))/,
                                        message: "Password should have six characters, numeric digit"
                                    }
                                })}
                            />
                            <label className="input_label">Password</label>
                            {errors.password && <span style={{ whiteSpace: "nowrap", fontSize: "13px", paddingLeft: "9px", color: "red" }} role="alert">{errors.password.message}</span>}
                        </div>

                        <button
                            type="submit"
                            className="btn login_btn"
                        >
                            Login
                        </button>

                    </div>

                    <div
                        className="close_btn"
                        title="Close"
                        onClick={() => toggleForm(false)}
                    >
                        &times;
                    </div>

                </form>
            </div>
        </div>
    )

};

export default SigninForm;