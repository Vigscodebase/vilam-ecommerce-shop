import React, { useContext } from 'react';
import { FaPlus, FaMinus } from 'react-icons/fa';
import cartContext from '../../contexts/cart/cartContext';


const QuantityBox = (props) => {

    const { itemId, itemQuantity } = props;
    // console.log(props)

    const { decrementItem, incrementItem } = useContext(cartContext);

    const decrementQuantity = (itemId) => decrementItem(itemId);
    const incrementQuantity = (itemId) => incrementItem(itemId);


    return (
        <>
            <div className="quantity_box">
                {itemQuantity > 1 &&
                    <button
                        type="button"
                        onClick={() => decrementQuantity(itemId)}
                    >
                        <FaMinus />
                    </button>
                }
                <span className="quantity_count">
                    {itemQuantity}
                </span>
                {itemQuantity == 1 &&
                    <button
                        type="button"
                        onClick={() => incrementQuantity(itemId)}
                    >
                        <FaPlus />
                    </button>
                }
                {itemQuantity > 1 &&
                    <button
                        type="button"
                        onClick={() => incrementQuantity(itemId)}
                    >
                        <FaPlus />
                    </button>
                }
            </div>
        </>
    );
};

export default QuantityBox;