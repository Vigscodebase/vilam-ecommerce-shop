import React, { useContext, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AiOutlineSearch, AiOutlineShoppingCart, AiOutlineUser } from 'react-icons/ai';
import { dropdownMenu } from '../../data/headerData';
import commonContext from '../../contexts/common/commonContext';
import cartContext from '../../contexts/cart/cartContext';
import AccountForm from '../form/AccountForm';
import SearchBar from './SearchBar';
import { useAuth } from "../../contexts/auth/authContext"
import AuthApi from "../../api/auth"

const Header = () => {

    const { formUserInfo, toggleForm, toggleSearch } = useContext(commonContext);
    const { cart } = useContext(cartContext);
    const [isSticky, setIsSticky] = useState(false);
    const [usrnme, setusrnme] = useState("");
    const { user, token } = useAuth();

    useEffect(() => {

        if (user || token || !token === "") {
            fetcSingleUser()
        }

    });

    const fetcSingleUser = () => {

        AuthApi.GetSingleUser(user)
            .then((response) => {
                setusrnme(response.data.data.name)
            })

    }

    // handle the sticky-header
    useEffect(() => {
        const handleIsSticky = () => window.scrollY >= 50 ? setIsSticky(true) : setIsSticky(false);

        window.addEventListener('scroll', handleIsSticky);

        return () => {
            window.removeEventListener('scroll', handleIsSticky);
        };
    }, [isSticky]);

    const cartQuantity = cart.length;

    const handleLogout = async () => {
        localStorage.removeItem("clientUser");
        localStorage.removeItem("clientToken");
        window.location.href = "/"
    };


    return (
        <>
            <header id="header" className={isSticky ? 'sticky' : ''}>
                <div className="container">
                    <div className="navbar">
                        <h2 className="nav_logo">
                            <Link to="/">Vilam Ecommerce</Link>
                        </h2>
                        <nav className="nav_actions">
                            <div className="search_action">
                                <span onClick={() => toggleSearch(true)}>
                                    <AiOutlineSearch />
                                </span>
                                <div className="tooltip">Search</div>
                            </div>

                            <div className="cart_action">
                                <Link to="/cart">
                                    <AiOutlineShoppingCart />
                                    {
                                        cartQuantity > 0 && (
                                            <span className="badge">{cartQuantity}</span>
                                        )
                                    }
                                </Link>
                                <div className="tooltip">Cart</div>
                            </div>

                            <div className="user_action">
                                <span>
                                    <AiOutlineUser />
                                </span>
                                <div className="dropdown_menu">
                                    <h4>Hello {usrnme && usrnme}</h4>
                                    {user && token ? (
                                        <p>Access account and manage orders</p>
                                    )
                                        :
                                        (
                                            <p>Login to access account and to manage orders</p>
                                        )
                                    }
                                    {/* { */}
                                    {/* !formUserInfo && ( */}
                                    {user && token ? (
                                        <button
                                            type="button"
                                            onClick={handleLogout}
                                        >
                                            Log Out
                                        </button>
                                    )
                                        :
                                        (
                                            <button
                                                type="button"
                                                onClick={() => toggleForm(true)}
                                            >
                                                Login / Signup
                                            </button>

                                        )
                                    }
                                    {/* ) */}
                                    {/* } */}
                                    <div className="separator"></div>
                                    {user && token ? (
                                        <ul>
                                            {
                                                dropdownMenu.map(item => {
                                                    const { id, link, path } = item;
                                                    return (
                                                        <li key={id}>
                                                            <Link to={path}>{link}</Link>
                                                        </li>
                                                    );
                                                })
                                            }
                                        </ul>
                                    )
                                        :
                                        (<span></span>)
                                    }
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </header>

            <SearchBar />
            <AccountForm />
        </>
    );
};

export default Header;