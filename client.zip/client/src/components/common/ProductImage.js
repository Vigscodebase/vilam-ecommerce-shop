import React, { useEffect, useState } from 'react';
import { getImageUrl, PLACEHOLDER_IMAGE } from '../../helpers/utils';

// Wraps a plain <img> for product photos: resolves the raw filename to a
// real URL via getImageUrl(), and if that URL fails to load (404, missing
// file, backend down, etc.) it swaps to a placeholder instead of leaving a
// broken-image icon on the page.
const ProductImage = ({ src, alt = 'product-img', ...rest }) => {
    const resolvedSrc = getImageUrl(src);
    const [imgSrc, setImgSrc] = useState(resolvedSrc);

    // Keep in sync if the caller passes a different image (e.g. switching
    // the selected thumbnail on the product details page).
    useEffect(() => {
        setImgSrc(resolvedSrc);
    }, [resolvedSrc]);

    return (
        <img
            src={imgSrc}
            alt={alt}
            onError={() => setImgSrc(PLACEHOLDER_IMAGE)}
            {...rest}
        />
    );
};

export default ProductImage;
