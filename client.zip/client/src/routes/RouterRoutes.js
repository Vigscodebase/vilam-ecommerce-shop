import React from 'react';
import { Routes, Route } from 'react-router';
import useScrollRestore from '../hooks/useScrollRestore';
import AllProducts from '../pages/AllProducts';
import Cart from '../pages/Cart';
import Home from '../pages/Home';
import ProductDetails from '../pages/ProductDetails';
import ErrorPage from '../pages/ErrorPage';
import VerifyEmail from '../pages/VerifyEmail';
import PrivateRoute from "../ProtectedRoute"
import UserAccount from '../pages/UserAccount';
import UserOrder from '../pages/UserOrder';
import Checkout from "../pages/checkout.jsx"
import OrderPlaced from '../pages/orderPlaced.jsx';
import ThankYou from '../pages/ThankYou.jsx';

const RouterRoutes = () => {

    useScrollRestore();

    return (
        <>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/all-products" element={<AllProducts />} />
                <Route path="/product-details/:productId" element={<ProductDetails />} />
                <Route path="/user/verify/*" element={<VerifyEmail />} />
                <Route path="*" element={<ErrorPage />} />

                <Route path='/' element={<PrivateRoute />}>
                    <Route path='/user-account' element={<UserAccount />} />
                    <Route path='/user-orders' element={<UserOrder />} />
                    <Route path='/checkout' element={<Checkout />} />
                    <Route path='/users-order-placed' element={<OrderPlaced />} />
                    <Route path='/thank-you' element={<ThankYou />} />
                </Route>

            </Routes>
        </>
    );
};

export default RouterRoutes;