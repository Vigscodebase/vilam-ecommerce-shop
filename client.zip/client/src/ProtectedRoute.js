import React, { useContext } from "react";
// import AuthContext from './contexts/auth/authContext';
import { useAuth } from './contexts/auth/authContext';
import { useNavigate, Outlet } from 'react-router-dom';
import SweetAlert from "react-bootstrap-sweetalert";

const ProtectedRoute = () => {
    const navigate = useNavigate();
    // const { user, token } = useContext(AuthContext);
    let { user, token } = useAuth();

    return (
        <>
            {
                (!user || !token || token === "") ?
                    <>
                        <SweetAlert
                            title="You must be signed in!"
                            onCancel={() => navigate("/")}
                            onConfirm={() => navigate("/")}
                            confirmBtnCssClass={"px-5"}
                        />
                    </>
                    : <Outlet />
            }
        </>
    )
}

export default ProtectedRoute

