import { CommonProvider } from './contexts/common/commonContext';
import { CartProvider } from './contexts/cart/cartContext';
import Header from './components/common/Header';
import RouterRoutes from './routes/RouterRoutes';
import Footer from './components/common/Footer';
import { AuthProvider } from './contexts/auth/authContext';
import BackTop from './components/common/BackTop';
import { FiltersProvider } from './contexts/filters/filtersContext';
import { ProductsProvider } from './contexts/products/productsContext';

const App = () => {

  let user = localStorage.getItem("clientUser");
  let token = localStorage.getItem("clientToken");

  return (
    <>
      <AuthProvider userData={user} userToken={token}>
        <CommonProvider>
          <ProductsProvider>
            <FiltersProvider>
              <CartProvider>
                <Header />
                <RouterRoutes />
                <Footer />
                <BackTop />
              </CartProvider>
            </FiltersProvider>
          </ProductsProvider>
        </CommonProvider>
      </AuthProvider>
    </>
  );
};

export default App;
