export const dropdownMenu = [
    {
        id: 1,
        link: "Orders",
        path: "/user-orders",
    },
    {
        id: 2,
        link: "Account",
        path: "/user-account",
    },
    // {
    //     id: 3,
    //     link: "Gift Cards",
    //     path: "*",
    // },
    // {
    //     id: 4,
    //     link: "Saved Cards",
    //     path: "*",
    // },
    // {
    //     id: 5,
    //     link: "Saved Addresses",
    //     path: "*",
    // },
];