import BrandApi from "../api/brand.js"
import ProductTagApi from "../api/productTag.js"
import CategoryApi from "../api/category.js"

let temp_producttag_data = []
let temp_brand_data = []
let temp_category_data = []

ProductTagApi.GetAllProductTag()
    .then(function (response) {
        // handle success

        response.data.data.map(item => {

            temp_producttag_data.push({
                id: item._id,
                title: item.title,
            })
        });

    })
    .catch(function (error) {
        // handle error
        console.log(error);
    })
    .finally(function () {
        // always executed
    });

BrandApi.GetAllBrand()
    .then(function (response) {
        // handle success

        response.data.data.map(item => {

            temp_brand_data.push({
                id: item._id,
                label: item.label,
                checked: item.checked
            })
        });

    })
    .catch(function (error) {
        // handle error
        console.log(error);
    })
    .finally(function () {
        // always executed
    });

CategoryApi.GetAllCategory()
    .then(function (response) {
        // handle success

        response.data.data.map(item => {

            temp_category_data.push({
                id: item._id,
                label: item.label,
                checked: item.checked
            })
        });

    })
    .catch(function (error) {
        // handle error
        console.log(error);
    })
    .finally(function () {
        // always executed
    });

export const sortMenu = temp_producttag_data
export const brandsMenu = temp_brand_data
export const categoryMenu = temp_category_data

