// DEPRECATED - do not import this file.
//
// This used to fire an API call at module-load time and export the result
// as a plain array before the request had resolved, which meant it was
// *always* empty by the time anything read it (see the long comment in
// contexts/products/productsContext.js for the full explanation).
//
// Product data now lives in contexts/products/productsContext.js and is
// consumed via the `useProducts()` hook, e.g.:
//
//     import { useProducts } from '../../contexts/products/productsContext';
//     const { products, loading, error } = useProducts();
//
// This file is kept only so a stray import doesn't crash the build; it
// always returns an empty array.
const productsData = [];

export default productsData;
