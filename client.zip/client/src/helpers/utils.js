
// ==== Image loading helpers ====
//
// Product images used to be referenced as a bare filename (e.g. "shoe1.jpg")
// and every component built its own "/images/prod_images/<filename>" path by
// hand. That meant the base path was duplicated in 8+ places, a couple of
// which forgot the prefix entirely (so the <img> tried to load a relative
// filename that doesn't exist), and there was no fallback when a filename
// was missing/empty or the file 404'd - the browser just showed a broken
// image icon.
//
// This app doesn't ship the actual image files or a backend in this bundle,
// so wherever the real images are served from, point REACT_APP_IMAGES_BASE_URL
// at it (e.g. "http://localhost:5000/images/prod_images" or a CDN URL) in a
// .env file. It defaults to the original "/images/prod_images" path.
const IMAGES_BASE_URL = (process.env.REACT_APP_IMAGES_BASE_URL || '/images/prod_images').replace(/\/+$/, '');

// Small inline SVG so a missing/broken product image never renders as a
// blank broken-image icon.
export const PLACEHOLDER_IMAGE =
    'data:image/svg+xml;charset=UTF-8,' +
    encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' +
        '<rect width="400" height="400" fill="#f1f1f1"/>' +
        '<text x="50%" y="50%" font-family="Arial, sans-serif" font-size="20" fill="#999" text-anchor="middle" dominant-baseline="middle">Image not available</text>' +
        '</svg>'
    );

// Turns a raw filename coming from the API/data layer into a real,
// loadable image URL. Safe to call with undefined/null/'' filenames.
export const getImageUrl = (filename) => {
    if (!filename) return PLACEHOLDER_IMAGE;

    // Already a full URL or a data URI - use as-is.
    if (/^(https?:)?\/\//i.test(filename) || filename.startsWith('data:')) {
        return filename;
    }

    // Already an absolute app path (e.g. someone already prefixed it).
    if (filename.startsWith('/')) return filename;

    return `${IMAGES_BASE_URL}/${filename}`;
};


// Display Money in Indian Format
export const displayMoney = (n) => {
    const numFormat = new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
    });

    return numFormat.format(n).split('.', 1);
};


// Calculate Discount Percentage
export const calculateDiscount = (discountedPrice, originalPrice) => {
    const discountedPercent = (discountedPrice / originalPrice) * 100;

    return Math.round(discountedPercent);
};


// Calculate Total Amount
export const calculateTotal = (arr) => {

    if (arr.length > 1 || arr.length == 1) {
        const total = Object.values(arr).reduce((accum, val) => accum + val, 0)
        return total;
    }

};